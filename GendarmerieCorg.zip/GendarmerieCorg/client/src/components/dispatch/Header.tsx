import { useAuth } from "@/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Shield, LogOut } from "lucide-react";

export default function Header() {
  const { user } = useAuth();

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  return (
    <header className="bg-gendarmerie-900 border-b border-gendarmerie-800 px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="w-10 h-10 bg-gendarmerie-600 rounded-lg flex items-center justify-center">
            <Shield className="text-white text-lg" />
          </div>
          <div>
            <h1 className="text-xl font-bold">CORG - Gendarmerie Nationale</h1>
            <p className="text-gendarmerie-300 text-sm">Centre Opérationnel de Renseignement</p>
          </div>
        </div>
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-2 bg-gendarmerie-800 px-3 py-2 rounded-lg">
            <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
            <span className="text-sm">En Service</span>
          </div>
          <div className="flex items-center space-x-2">
            <div className="w-8 h-8 bg-gendarmerie-600 rounded-full flex items-center justify-center">
              <i className="fas fa-user text-sm"></i>
            </div>
            <span className="text-sm font-medium">
              {user?.firstName ? `${user.firstName} ${user.lastName}` : user?.email}
            </span>
          </div>
          <Button 
            onClick={handleLogout}
            variant="destructive"
            size="sm"
            className="bg-red-600 hover:bg-red-700"
          >
            <LogOut className="mr-2 h-4 w-4" />
            Déconnexion
          </Button>
        </div>
      </div>
    </header>
  );
}
