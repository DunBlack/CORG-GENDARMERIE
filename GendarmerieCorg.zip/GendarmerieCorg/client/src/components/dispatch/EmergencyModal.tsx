import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { AlertTriangle, Radio } from "lucide-react";

interface EmergencyModalProps {
  isOpen: boolean;
  vehicleId?: number;
  unitId?: number;
  vehicleName?: string;
  onClose: () => void;
}

export default function EmergencyModal({ 
  isOpen, 
  vehicleId, 
  unitId, 
  vehicleName, 
  onClose 
}: EmergencyModalProps) {
  const [message, setMessage] = useState("");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const emergencyMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/emergency", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/emergency"] });
      toast({
        title: "Alerte d'urgence envoyée",
        description: "L'alerte d'urgence a été diffusée à toutes les unités.",
      });
      onClose();
      setMessage("");
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible d'envoyer l'alerte d'urgence.",
        variant: "destructive",
      });
    },
  });

  const handleSendAlert = () => {
    if (!message.trim()) {
      toast({
        title: "Message requis",
        description: "Veuillez saisir un message d'urgence.",
        variant: "destructive",
      });
      return;
    }

    emergencyMutation.mutate({
      vehicleId,
      unitId,
      message: message.trim(),
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="bg-gendarmerie-800 border-red-500 max-w-md">
        <DialogHeader>
          <div className="flex items-center space-x-3 mb-4">
            <div className="w-12 h-12 bg-red-600 rounded-full flex items-center justify-center">
              <AlertTriangle className="text-white text-xl animate-pulse" />
            </div>
            <div>
              <DialogTitle className="font-bold text-lg text-red-400">
                ALERTE D'URGENCE
              </DialogTitle>
              <p className="text-sm text-gendarmerie-300">Unité en détresse</p>
            </div>
          </div>
        </DialogHeader>

        <div className="mb-4">
          <p className="text-sm mb-2">Unité concernée:</p>
          <p className="font-medium">{vehicleName || "Unité inconnue"}</p>
        </div>

        <div className="mb-6">
          <label className="block text-sm font-medium mb-2">Message d'urgence:</label>
          <Textarea
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            className="bg-gendarmerie-700 border-gendarmerie-600 focus:border-red-500 text-white"
            rows={3}
            placeholder="Détails de l'urgence..."
          />
        </div>

        <div className="flex space-x-3">
          <Button
            onClick={handleSendAlert}
            disabled={emergencyMutation.isPending}
            className="flex-1 bg-red-600 hover:bg-red-700 font-medium"
          >
            <Radio className="mr-2 h-4 w-4" />
            Diffuser Alerte
          </Button>
          <Button
            onClick={onClose}
            variant="outline"
            className="border-gendarmerie-600 text-gendarmerie-200"
          >
            Annuler
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
