import { useState } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useForm } from "react-hook-form";
import { Form, FormControl, FormField, FormItem, FormLabel } from "@/components/ui/form";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import PersonnelItem from "./PersonnelItem";
import { Plus, AlertTriangle, FileText } from "lucide-react";

interface SidebarProps {
  availablePersonnel: any[];
}

export default function Sidebar({ availablePersonnel }: SidebarProps) {
  const [newInterventionOpen, setNewInterventionOpen] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const form = useForm({
    defaultValues: {
      title: "",
      description: "",
      location: "",
      priority: "normal",
    },
  });

  const createInterventionMutation = useMutation({
    mutationFn: async (data: any) => {
      const response = await apiRequest("POST", "/api/interventions", data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/interventions"] });
      toast({
        title: "Intervention créée",
        description: "L'intervention a été créée avec succès.",
      });
      setNewInterventionOpen(false);
      form.reset();
    },
    onError: () => {
      toast({
        title: "Erreur",
        description: "Impossible de créer l'intervention.",
        variant: "destructive",
      });
    },
  });

  const handleNewIntervention = (data: any) => {
    createInterventionMutation.mutate(data);
  };

  const handleAlertAll = () => {
    toast({
      title: "Alerte générale",
      description: "Alerte générale envoyée à toutes les unités !",
    });
  };

  const handleViewReports = () => {
    toast({
      title: "Rapports",
      description: "Fonction de rapports en développement.",
    });
  };

  const statusLegend = [
    { status: 1, color: "bg-green-500", label: "1 - Début Patrouille" },
    { status: 2, color: "bg-blue-500", label: "2 - Fin Patrouille" },
    { status: 3, color: "bg-yellow-500", label: "3 - Arrivée sur Lieux" },
    { status: 4, color: "bg-orange-500", label: "4 - Début Intervention" },
    { status: 5, color: "bg-purple-500", label: "5 - Fin Intervention" },
    { status: 0, color: "bg-red-500 animate-pulse", label: "URGENCE" },
  ];

  return (
    <aside className="w-80 bg-gendarmerie-900 border-r border-gendarmerie-800 flex flex-col">
      {/* Status Legend */}
      <div className="p-4 border-b border-gendarmerie-800">
        <h3 className="font-semibold mb-3 text-gendarmerie-100">Statuts des Unités</h3>
        <div className="space-y-2 text-sm">
          {statusLegend.map((item) => (
            <div key={item.status} className="flex items-center space-x-2">
              <div className={`w-3 h-3 ${item.color} rounded-full`}></div>
              <span>{item.label}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Available Personnel */}
      <div className="p-4 border-b border-gendarmerie-800">
        <h3 className="font-semibold mb-3 text-gendarmerie-100">Personnel Disponible</h3>
        <div className="space-y-2">
          {availablePersonnel.length === 0 ? (
            <div className="text-gendarmerie-400 text-sm text-center py-4">
              Aucun personnel disponible
            </div>
          ) : (
            availablePersonnel.map((person) => (
              <PersonnelItem key={person.id} person={person} />
            ))
          )}
        </div>
      </div>

      {/* Quick Actions */}
      <div className="p-4 flex-1">
        <h3 className="font-semibold mb-3 text-gendarmerie-100">Actions Rapides</h3>
        <div className="space-y-2">
          <Dialog open={newInterventionOpen} onOpenChange={setNewInterventionOpen}>
            <DialogTrigger asChild>
              <Button className="w-full bg-gendarmerie-700 hover:bg-gendarmerie-600 text-sm">
                <Plus className="mr-2 h-4 w-4" />
                Nouvelle Intervention
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-gendarmerie-800 border-gendarmerie-700">
              <DialogHeader>
                <DialogTitle className="text-gendarmerie-100">Nouvelle Intervention</DialogTitle>
              </DialogHeader>
              <Form {...form}>
                <form onSubmit={form.handleSubmit(handleNewIntervention)} className="space-y-4">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gendarmerie-200">Titre</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            className="bg-gendarmerie-700 border-gendarmerie-600 text-white"
                            placeholder="Titre de l'intervention"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="location"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gendarmerie-200">Lieu</FormLabel>
                        <FormControl>
                          <Input 
                            {...field} 
                            className="bg-gendarmerie-700 border-gendarmerie-600 text-white"
                            placeholder="Lieu de l'intervention"
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel className="text-gendarmerie-200">Description</FormLabel>
                        <FormControl>
                          <Textarea 
                            {...field} 
                            className="bg-gendarmerie-700 border-gendarmerie-600 text-white"
                            placeholder="Description de l'intervention"
                            rows={3}
                          />
                        </FormControl>
                      </FormItem>
                    )}
                  />
                  <div className="flex space-x-2">
                    <Button 
                      type="submit" 
                      className="flex-1 bg-gendarmerie-600 hover:bg-gendarmerie-500"
                      disabled={createInterventionMutation.isPending}
                    >
                      Créer
                    </Button>
                    <Button 
                      type="button" 
                      variant="outline" 
                      onClick={() => setNewInterventionOpen(false)}
                      className="border-gendarmerie-600 text-gendarmerie-200"
                    >
                      Annuler
                    </Button>
                  </div>
                </form>
              </Form>
            </DialogContent>
          </Dialog>
          
          <Button 
            onClick={handleAlertAll}
            className="w-full bg-yellow-600 hover:bg-yellow-700 text-sm"
          >
            <AlertTriangle className="mr-2 h-4 w-4" />
            Alerte Générale
          </Button>
          
          <Button 
            onClick={handleViewReports}
            className="w-full bg-gendarmerie-700 hover:bg-gendarmerie-600 text-sm"
          >
            <FileText className="mr-2 h-4 w-4" />
            Rapports
          </Button>
        </div>
      </div>
    </aside>
  );
}
