import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { useDrop } from "react-dnd";
import { apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { Bike, Dog, TriangleAlert, X } from "lucide-react";
import { useState } from "react";

interface UnitCardProps {
  unit: any;
  onEmergencyAlert: (vehicleId?: number, unitId?: number, unitName?: string) => void;
}

export default function UnitCard({ unit, onEmergencyAlert }: UnitCardProps) {
  const [location, setLocation] = useState(unit.currentLocation || "");
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const statusMutation = useMutation({
    mutationFn: async ({ status }: { status: number }) => {
      await apiRequest("PATCH", `/api/units/${unit.id}/status`, { status });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/units"] });
    },
  });

  const assignmentMutation = useMutation({
    mutationFn: async ({ personnelId }: { personnelId: number }) => {
      await apiRequest("POST", "/api/assignments/unit", {
        personnelId,
        unitId: unit.id,
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/units"] });
      queryClient.invalidateQueries({ queryKey: ["/api/personnel/available"] });
      toast({
        title: "Personnel assigné",
        description: "Le personnel a été assigné à l'unité.",
      });
    },
  });

  const [{ isOver }, drop] = useDrop(() => ({
    accept: "personnel",
    drop: (item: any) => {
      assignmentMutation.mutate({ personnelId: item.id });
    },
    collect: (monitor) => ({
      isOver: !!monitor.isOver(),
    }),
  }));

  const handleStatusChange = (status: number) => {
    statusMutation.mutate({ status });
  };

  const handleEmergency = () => {
    onEmergencyAlert(undefined, unit.id, unit.name);
  };

  const getStatusColor = (status: number) => {
    switch (status) {
      case 1: return "bg-green-500";
      case 2: return "bg-blue-500";
      case 3: return "bg-yellow-500";
      case 4: return "bg-orange-500";
      case 5: return "bg-purple-500";
      default: return "bg-green-500";
    }
  };

  const getStatusText = (status: number) => {
    switch (status) {
      case 1: return "Début Patrouille";
      case 2: return "Fin Patrouille";
      case 3: return "Sur les Lieux";
      case 4: return "Intervention";
      case 5: return "Fin Intervention";
      default: return "Disponible";
    }
  };

  const getUnitIcon = (type: string) => {
    switch (type) {
      case "motard":
        return <Bike className="text-gendarmerie-400 text-xl" />;
      case "cyno":
        return <Dog className="text-gendarmerie-400 text-xl" />;
      default:
        return <i className="fas fa-shield-alt text-gendarmerie-400 text-xl"></i>;
    }
  };

  return (
    <div
      ref={drop}
      className={`bg-gendarmerie-700 border-2 border-dashed border-gendarmerie-600 rounded-lg p-4 transition-colors ${
        isOver ? "border-gendarmerie-500" : ""
      }`}
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center space-x-3">
          {getUnitIcon(unit.type)}
          <div>
            <h4 className="font-medium">{unit.name}</h4>
            <p className="text-sm text-gendarmerie-300">{unit.description}</p>
          </div>
        </div>
        <div className="flex items-center space-x-2">
          <div className={`w-3 h-3 ${getStatusColor(unit.status)} rounded-full`}></div>
          <span className="text-sm">{getStatusText(unit.status)}</span>
        </div>
      </div>

      <div className="border-t border-gendarmerie-600 pt-3 mb-3">
        <label className="block text-sm font-medium mb-2">Lieu:</label>
        <Input
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          className="bg-gendarmerie-800 border-gendarmerie-600 text-white text-sm"
          placeholder="Localisation de l'unité"
        />
      </div>

      <div className="border-t border-gendarmerie-600 pt-3">
        <p className="text-sm font-medium mb-2">Personnel assigné:</p>
        <div className="min-h-[40px] space-y-2">
          {unit.assignments?.length > 0 ? (
            unit.assignments.map((assignment: any) => (
              <div key={assignment.id} className="bg-gendarmerie-600 p-2 rounded flex items-center justify-between">
                <div className="flex items-center space-x-2">
                  <i className="fas fa-user text-sm"></i>
                  <span className="text-sm">{assignment.personnel.name}</span>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-red-400 hover:text-red-300 h-auto p-1"
                >
                  <X className="h-3 w-3" />
                </Button>
              </div>
            ))
          ) : (
            <div className="text-xs text-gendarmerie-400 text-center py-2 border border-dashed border-gendarmerie-600 rounded">
              Glisser un gendarme ici
            </div>
          )}
        </div>
      </div>

      <div className="mt-3 flex space-x-2">
        <div className="flex space-x-1 flex-1">
          {[1, 2, 3, 4, 5].map((status) => (
            <Button
              key={status}
              size="sm"
              onClick={() => handleStatusChange(status)}
              className={`px-2 py-1 text-xs transition-colors ${
                unit.status === status
                  ? `${getStatusColor(status)} text-white`
                  : "bg-gendarmerie-600 hover:bg-gendarmerie-500"
              }`}
            >
              {status}
            </Button>
          ))}
        </div>
        <Button
          size="sm"
          onClick={handleEmergency}
          className="bg-red-600 hover:bg-red-700 px-3 py-1 text-xs font-medium"
        >
          <TriangleAlert className="mr-1 h-3 w-3" />
          URGENCE
        </Button>
      </div>
    </div>
  );
}
