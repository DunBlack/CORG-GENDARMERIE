import { useDrag } from "react-dnd";
import { GripVertical, User } from "lucide-react";

interface PersonnelItemProps {
  person: any;
}

export default function PersonnelItem({ person }: PersonnelItemProps) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: "personnel",
    item: { id: person.id, name: person.name, rank: person.rank, badge: person.badge },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }));

  return (
    <div
      ref={drag}
      className={`bg-gendarmerie-800 p-3 rounded-lg cursor-move hover:bg-gendarmerie-700 transition-colors ${
        isDragging ? "opacity-50" : ""
      }`}
    >
      <div className="flex items-center space-x-2">
        <GripVertical className="text-gendarmerie-400 h-4 w-4" />
        <div className="w-8 h-8 bg-gendarmerie-600 rounded-full flex items-center justify-center">
          <User className="h-4 w-4" />
        </div>
        <div>
          <div className="font-medium text-sm">{person.name}</div>
          <div className="text-xs text-gendarmerie-300">Matricule: {person.badge}</div>
        </div>
      </div>
    </div>
  );
}
