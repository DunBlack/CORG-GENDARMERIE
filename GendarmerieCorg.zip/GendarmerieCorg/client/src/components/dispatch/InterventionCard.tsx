import { useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { apiRequest } from "@/lib/queryClient";
import { Eye, Check } from "lucide-react";
import { useState } from "react";

interface InterventionCardProps {
  intervention: any;
}

export default function InterventionCard({ intervention }: InterventionCardProps) {
  const [location, setLocation] = useState(intervention.location);
  const queryClient = useQueryClient();

  const locationMutation = useMutation({
    mutationFn: async ({ location }: { location: string }) => {
      await apiRequest("PATCH", `/api/interventions/${intervention.id}/location`, { location });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/interventions"] });
    },
  });

  const closeMutation = useMutation({
    mutationFn: async () => {
      await apiRequest("PATCH", `/api/interventions/${intervention.id}/close`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/interventions"] });
    },
  });

  const handleLocationChange = () => {
    if (location !== intervention.location) {
      locationMutation.mutate({ location });
    }
  };

  const handleClose = () => {
    closeMutation.mutate();
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "emergency": return "bg-red-500";
      case "high": return "bg-orange-500";
      case "normal": return "bg-yellow-500";
      default: return "bg-green-500";
    }
  };

  return (
    <div className="bg-gendarmerie-800 rounded-xl p-6 border border-gendarmerie-700">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="font-semibold text-lg">{intervention.title}</h3>
          <p className="text-gendarmerie-300 text-sm">{intervention.description}</p>
        </div>
        <div className="flex items-center space-x-2">
          <div className={`w-3 h-3 ${getPriorityColor(intervention.priority)} rounded-full`}></div>
          <span className="text-sm font-medium capitalize">{intervention.priority}</span>
        </div>
      </div>

      <div className="mb-4">
        <label className="block text-sm font-medium mb-2">Lieu d'intervention:</label>
        <Input
          value={location}
          onChange={(e) => setLocation(e.target.value)}
          onBlur={handleLocationChange}
          className="bg-gendarmerie-700 border-gendarmerie-600 text-white"
          placeholder="Lieu de l'intervention"
        />
      </div>

      <div className="mb-4">
        <p className="text-sm font-medium mb-2">Unités assignées:</p>
        <div className="space-y-2">
          {intervention.assignments?.length > 0 ? (
            intervention.assignments.map((assignment: any) => (
              <div key={assignment.id} className="flex items-center justify-between bg-gendarmerie-700 p-2 rounded-lg">
                <span className="text-sm">
                  {assignment.vehicle ? assignment.vehicle.callSign : assignment.unit?.name}
                </span>
                <div className="flex space-x-1">
                  <Button size="sm" variant="outline" className="border-yellow-600 text-yellow-400">
                    Statut 3
                  </Button>
                </div>
              </div>
            ))
          ) : (
            <div className="text-xs text-gendarmerie-400 text-center py-2 border border-dashed border-gendarmerie-600 rounded">
              Aucune unité assignée
            </div>
          )}
        </div>
      </div>

      <div className="flex space-x-2">
        <Button className="flex-1 bg-gendarmerie-600 hover:bg-gendarmerie-500">
          <Eye className="mr-2 h-4 w-4" />
          Voir Détails
        </Button>
        <Button 
          onClick={handleClose}
          className="bg-green-600 hover:bg-green-700"
          disabled={closeMutation.isPending}
        >
          <Check className="mr-2 h-4 w-4" />
          Clôturer
        </Button>
      </div>
    </div>
  );
}
