import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";

export function useWebSocket() {
  const queryClient = useQueryClient();
  const { toast } = useToast();

  useEffect(() => {
    const protocol = window.location.protocol === "https:" ? "wss:" : "ws:";
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const socket = new WebSocket(wsUrl);

    socket.onopen = () => {
      console.log("Connected to WebSocket");
    };

    socket.onmessage = (event) => {
      try {
        const message = JSON.parse(event.data);
        
        switch (message.type) {
          case "VEHICLE_STATUS_UPDATE":
          case "VEHICLE_LOCATION_UPDATE":
          case "VEHICLE_EMERGENCY_UPDATE":
            queryClient.invalidateQueries({ queryKey: ["/api/vehicles"] });
            break;
            
          case "UNIT_STATUS_UPDATE":
            queryClient.invalidateQueries({ queryKey: ["/api/units"] });
            break;
            
          case "PERSONNEL_ASSIGNED":
          case "PERSONNEL_REMOVED":
            queryClient.invalidateQueries({ queryKey: ["/api/vehicles"] });
            queryClient.invalidateQueries({ queryKey: ["/api/units"] });
            queryClient.invalidateQueries({ queryKey: ["/api/personnel/available"] });
            break;
            
          case "NEW_INTERVENTION":
            queryClient.invalidateQueries({ queryKey: ["/api/interventions"] });
            toast({
              title: "Nouvelle intervention",
              description: `Intervention créée: ${message.payload.title}`,
            });
            break;
            
          case "INTERVENTION_LOCATION_UPDATE":
            queryClient.invalidateQueries({ queryKey: ["/api/interventions"] });
            break;
            
          case "EMERGENCY_ALERT":
            queryClient.invalidateQueries({ queryKey: ["/api/emergency"] });
            toast({
              title: "🚨 ALERTE D'URGENCE 🚨",
              description: message.payload.message,
              variant: "destructive",
            });
            break;
            
          default:
            console.log("Unknown WebSocket message type:", message.type);
        }
      } catch (error) {
        console.error("Error parsing WebSocket message:", error);
      }
    };

    socket.onclose = () => {
      console.log("Disconnected from WebSocket");
    };

    socket.onerror = (error) => {
      console.error("WebSocket error:", error);
    };

    return () => {
      socket.close();
    };
  }, [queryClient, toast]);
}
