import { useDrag, useDrop } from "react-dnd";

export function usePersonnelDrag(person: any) {
  const [{ isDragging }, drag] = useDrag(() => ({
    type: "personnel",
    item: { 
      id: person.id, 
      name: person.name, 
      rank: person.rank, 
      badge: person.badge 
    },
    collect: (monitor) => ({
      isDragging: !!monitor.isDragging(),
    }),
  }));

  return { isDragging, drag };
}

export function useVehicleDrop(onDrop: (personnelId: number) => void) {
  const [{ isOver }, drop] = useDrop(() => ({
    accept: "personnel",
    drop: (item: any) => {
      onDrop(item.id);
    },
    collect: (monitor) => ({
      isOver: !!monitor.isOver(),
    }),
  }));

  return { isOver, drop };
}

export function useUnitDrop(onDrop: (personnelId: number) => void) {
  const [{ isOver }, drop] = useDrop(() => ({
    accept: "personnel",
    drop: (item: any) => {
      onDrop(item.id);
    },
    collect: (monitor) => ({
      isOver: !!monitor.isOver(),
    }),
  }));

  return { isOver, drop };
}
