import { useState } from "react";
import { useQuery } from "@tanstack/react-query";
import Header from "@/components/dispatch/Header";
import Sidebar from "@/components/dispatch/Sidebar";
import VehicleCard from "@/components/dispatch/VehicleCard";
import UnitCard from "@/components/dispatch/UnitCard";
import InterventionCard from "@/components/dispatch/InterventionCard";
import EmergencyModal from "@/components/dispatch/EmergencyModal";
import { useWebSocket } from "@/hooks/useWebSocket";
import { DndProvider } from "react-dnd";
import { HTML5Backend } from "react-dnd-html5-backend";

export default function Dashboard() {
  const [emergencyModal, setEmergencyModal] = useState<{
    isOpen: boolean;
    vehicleId?: number;
    unitId?: number;
    vehicleName?: string;
  }>({ isOpen: false });

  // Fetch data
  const { data: vehicles = [] } = useQuery({
    queryKey: ["/api/vehicles"],
  });

  const { data: units = [] } = useQuery({
    queryKey: ["/api/units"],
  });

  const { data: interventions = [] } = useQuery({
    queryKey: ["/api/interventions"],
  });

  const { data: availablePersonnel = [] } = useQuery({
    queryKey: ["/api/personnel/available"],
  });

  // WebSocket for real-time updates
  useWebSocket();

  const handleEmergencyAlert = (vehicleId?: number, unitId?: number, vehicleName?: string) => {
    setEmergencyModal({
      isOpen: true,
      vehicleId,
      unitId,
      vehicleName,
    });
  };

  const closeEmergencyModal = () => {
    setEmergencyModal({ isOpen: false });
  };

  return (
    <DndProvider backend={HTML5Backend}>
      <div className="min-h-screen bg-gendarmerie-950 text-white">
        <Header />
        
        <div className="flex h-[calc(100vh-80px)]">
          <Sidebar availablePersonnel={availablePersonnel} />
          
          <main className="flex-1 p-6 overflow-auto">
            {/* Current Interventions */}
            <div className="mb-6">
              <div className="flex items-center justify-between mb-4">
                <h2 className="text-2xl font-bold text-gendarmerie-100">
                  Interventions en Cours
                </h2>
                <div className="flex items-center space-x-2 text-sm text-gendarmerie-300">
                  <i className="fas fa-clock"></i>
                  <span>{new Date().toLocaleTimeString('fr-FR')}</span>
                </div>
              </div>
              
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {interventions.map((intervention) => (
                  <InterventionCard 
                    key={intervention.id} 
                    intervention={intervention}
                  />
                ))}
              </div>
            </div>

            {/* Vehicle and Unit Management */}
            <div className="grid grid-cols-1 xl:grid-cols-2 gap-6">
              {/* Vehicle Fleet */}
              <div className="bg-gendarmerie-800 rounded-xl p-6">
                <h3 className="text-xl font-semibold mb-4 text-gendarmerie-100">
                  Flotte de Véhicules
                </h3>
                
                <div className="space-y-4">
                  {vehicles.map((vehicle) => (
                    <VehicleCard 
                      key={vehicle.id} 
                      vehicle={vehicle}
                      onEmergencyAlert={handleEmergencyAlert}
                    />
                  ))}
                </div>
              </div>

              {/* Specialized Units */}
              <div className="bg-gendarmerie-800 rounded-xl p-6">
                <h3 className="text-xl font-semibold mb-4 text-gendarmerie-100">
                  Unités Spécialisées
                </h3>
                
                <div className="space-y-4">
                  {units.map((unit) => (
                    <UnitCard 
                      key={unit.id} 
                      unit={unit}
                      onEmergencyAlert={handleEmergencyAlert}
                    />
                  ))}
                </div>
              </div>
            </div>
          </main>
        </div>

        <EmergencyModal 
          isOpen={emergencyModal.isOpen}
          vehicleId={emergencyModal.vehicleId}
          unitId={emergencyModal.unitId}
          vehicleName={emergencyModal.vehicleName}
          onClose={closeEmergencyModal}
        />
      </div>
    </DndProvider>
  );
}
