import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Shield } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gendarmerie-950 flex items-center justify-center p-4">
      <Card className="w-full max-w-md bg-gendarmerie-900 border-gendarmerie-800">
        <CardHeader className="text-center">
          <div className="mx-auto w-16 h-16 bg-gendarmerie-600 rounded-lg flex items-center justify-center mb-4">
            <Shield className="h-8 w-8 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-gendarmerie-100">
            CORG - Gendarmerie Nationale
          </CardTitle>
          <p className="text-gendarmerie-300 text-sm">
            Centre Opérationnel de Renseignement
          </p>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-gendarmerie-300 text-center text-sm">
            Connectez-vous avec vos identifiants pour accéder au système de dispatch.
          </p>
          <Button 
            onClick={handleLogin}
            className="w-full bg-gendarmerie-600 hover:bg-gendarmerie-700 text-white"
          >
            Se connecter
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
