import type { Express } from "express";
import { createServer, type Server } from "http";
import { WebSocketServer, WebSocket } from "ws";
import { storage } from "./storage";
import { setupAuth, isAuthenticated } from "./replitAuth";
import { insertPersonnelSchema, insertVehicleSchema, insertUnitSchema, insertInterventionSchema, insertEmergencyAlertSchema } from "@shared/schema";

export async function registerRoutes(app: Express): Promise<Server> {
  // Auth middleware
  await setupAuth(app);

  // Auth routes
  app.get('/api/auth/user', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const user = await storage.getUser(userId);
      res.json(user);
    } catch (error) {
      console.error("Error fetching user:", error);
      res.status(500).json({ message: "Failed to fetch user" });
    }
  });

  // Personnel routes
  app.get('/api/personnel', isAuthenticated, async (req, res) => {
    try {
      const personnel = await storage.getAllPersonnel();
      res.json(personnel);
    } catch (error) {
      console.error("Error fetching personnel:", error);
      res.status(500).json({ message: "Failed to fetch personnel" });
    }
  });

  app.get('/api/personnel/available', isAuthenticated, async (req, res) => {
    try {
      const personnel = await storage.getAvailablePersonnel();
      res.json(personnel);
    } catch (error) {
      console.error("Error fetching available personnel:", error);
      res.status(500).json({ message: "Failed to fetch available personnel" });
    }
  });

  app.post('/api/personnel', isAuthenticated, async (req, res) => {
    try {
      const personnelData = insertPersonnelSchema.parse(req.body);
      const personnel = await storage.createPersonnel(personnelData);
      res.json(personnel);
    } catch (error) {
      console.error("Error creating personnel:", error);
      res.status(500).json({ message: "Failed to create personnel" });
    }
  });

  // Vehicle routes
  app.get('/api/vehicles', isAuthenticated, async (req, res) => {
    try {
      const vehicles = await storage.getAllVehicles();
      res.json(vehicles);
    } catch (error) {
      console.error("Error fetching vehicles:", error);
      res.status(500).json({ message: "Failed to fetch vehicles" });
    }
  });

  app.post('/api/vehicles', isAuthenticated, async (req, res) => {
    try {
      const vehicleData = insertVehicleSchema.parse(req.body);
      const vehicle = await storage.createVehicle(vehicleData);
      res.json(vehicle);
    } catch (error) {
      console.error("Error creating vehicle:", error);
      res.status(500).json({ message: "Failed to create vehicle" });
    }
  });

  app.patch('/api/vehicles/:id/status', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      await storage.updateVehicleStatus(parseInt(id), status);
      
      // Broadcast status update via WebSocket
      broadcastToAll({
        type: 'VEHICLE_STATUS_UPDATE',
        payload: { vehicleId: parseInt(id), status }
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating vehicle status:", error);
      res.status(500).json({ message: "Failed to update vehicle status" });
    }
  });

  app.patch('/api/vehicles/:id/location', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const { location } = req.body;
      await storage.updateVehicleLocation(parseInt(id), location);
      
      // Broadcast location update via WebSocket
      broadcastToAll({
        type: 'VEHICLE_LOCATION_UPDATE',
        payload: { vehicleId: parseInt(id), location }
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating vehicle location:", error);
      res.status(500).json({ message: "Failed to update vehicle location" });
    }
  });

  app.patch('/api/vehicles/:id/emergency', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const { isEmergency } = req.body;
      await storage.updateVehicleEmergency(parseInt(id), isEmergency);
      
      // Broadcast emergency update via WebSocket
      broadcastToAll({
        type: 'VEHICLE_EMERGENCY_UPDATE',
        payload: { vehicleId: parseInt(id), isEmergency }
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating vehicle emergency status:", error);
      res.status(500).json({ message: "Failed to update vehicle emergency status" });
    }
  });

  // Unit routes
  app.get('/api/units', isAuthenticated, async (req, res) => {
    try {
      const units = await storage.getAllUnits();
      res.json(units);
    } catch (error) {
      console.error("Error fetching units:", error);
      res.status(500).json({ message: "Failed to fetch units" });
    }
  });

  app.post('/api/units', isAuthenticated, async (req, res) => {
    try {
      const unitData = insertUnitSchema.parse(req.body);
      const unit = await storage.createUnit(unitData);
      res.json(unit);
    } catch (error) {
      console.error("Error creating unit:", error);
      res.status(500).json({ message: "Failed to create unit" });
    }
  });

  app.patch('/api/units/:id/status', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const { status } = req.body;
      await storage.updateUnitStatus(parseInt(id), status);
      
      // Broadcast status update via WebSocket
      broadcastToAll({
        type: 'UNIT_STATUS_UPDATE',
        payload: { unitId: parseInt(id), status }
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating unit status:", error);
      res.status(500).json({ message: "Failed to update unit status" });
    }
  });

  // Assignment routes
  app.post('/api/assignments/vehicle', isAuthenticated, async (req, res) => {
    try {
      const { personnelId, vehicleId, isLeader } = req.body;
      await storage.assignPersonnelToVehicle(personnelId, vehicleId, isLeader);
      
      // Broadcast assignment update via WebSocket
      broadcastToAll({
        type: 'PERSONNEL_ASSIGNED',
        payload: { personnelId, vehicleId, type: 'vehicle' }
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error assigning personnel to vehicle:", error);
      res.status(500).json({ message: "Failed to assign personnel to vehicle" });
    }
  });

  app.post('/api/assignments/unit', isAuthenticated, async (req, res) => {
    try {
      const { personnelId, unitId } = req.body;
      await storage.assignPersonnelToUnit(personnelId, unitId);
      
      // Broadcast assignment update via WebSocket
      broadcastToAll({
        type: 'PERSONNEL_ASSIGNED',
        payload: { personnelId, unitId, type: 'unit' }
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error assigning personnel to unit:", error);
      res.status(500).json({ message: "Failed to assign personnel to unit" });
    }
  });

  app.delete('/api/assignments/vehicle/:personnelId/:vehicleId', isAuthenticated, async (req, res) => {
    try {
      const { personnelId, vehicleId } = req.params;
      await storage.removePersonnelFromVehicle(parseInt(personnelId), parseInt(vehicleId));
      
      // Broadcast removal update via WebSocket
      broadcastToAll({
        type: 'PERSONNEL_REMOVED',
        payload: { personnelId: parseInt(personnelId), vehicleId: parseInt(vehicleId), type: 'vehicle' }
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error removing personnel from vehicle:", error);
      res.status(500).json({ message: "Failed to remove personnel from vehicle" });
    }
  });

  // Intervention routes
  app.get('/api/interventions', isAuthenticated, async (req, res) => {
    try {
      const interventions = await storage.getAllActiveInterventions();
      res.json(interventions);
    } catch (error) {
      console.error("Error fetching interventions:", error);
      res.status(500).json({ message: "Failed to fetch interventions" });
    }
  });

  app.post('/api/interventions', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const interventionData = insertInterventionSchema.parse({
        ...req.body,
        createdBy: userId
      });
      const intervention = await storage.createIntervention(interventionData);
      
      // Broadcast new intervention via WebSocket
      broadcastToAll({
        type: 'NEW_INTERVENTION',
        payload: intervention
      });
      
      res.json(intervention);
    } catch (error) {
      console.error("Error creating intervention:", error);
      res.status(500).json({ message: "Failed to create intervention" });
    }
  });

  app.patch('/api/interventions/:id/location', isAuthenticated, async (req, res) => {
    try {
      const { id } = req.params;
      const { location } = req.body;
      await storage.updateInterventionLocation(parseInt(id), location);
      
      // Broadcast location update via WebSocket
      broadcastToAll({
        type: 'INTERVENTION_LOCATION_UPDATE',
        payload: { interventionId: parseInt(id), location }
      });
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error updating intervention location:", error);
      res.status(500).json({ message: "Failed to update intervention location" });
    }
  });

  // Emergency routes
  app.post('/api/emergency', isAuthenticated, async (req: any, res) => {
    try {
      const userId = req.user.claims.sub;
      const alertData = insertEmergencyAlertSchema.parse({
        ...req.body,
        createdBy: userId
      });
      const alert = await storage.createEmergencyAlert(alertData);
      
      // Broadcast emergency alert via WebSocket
      broadcastToAll({
        type: 'EMERGENCY_ALERT',
        payload: alert
      });
      
      res.json(alert);
    } catch (error) {
      console.error("Error creating emergency alert:", error);
      res.status(500).json({ message: "Failed to create emergency alert" });
    }
  });

  app.get('/api/emergency', isAuthenticated, async (req, res) => {
    try {
      const alerts = await storage.getActiveEmergencyAlerts();
      res.json(alerts);
    } catch (error) {
      console.error("Error fetching emergency alerts:", error);
      res.status(500).json({ message: "Failed to fetch emergency alerts" });
    }
  });

  const httpServer = createServer(app);

  // WebSocket setup
  const wss = new WebSocketServer({ server: httpServer, path: '/ws' });
  const clients = new Set<WebSocket>();

  wss.on('connection', (ws) => {
    clients.add(ws);
    console.log('Client connected to WebSocket');

    ws.on('close', () => {
      clients.delete(ws);
      console.log('Client disconnected from WebSocket');
    });

    ws.on('error', (error) => {
      console.error('WebSocket error:', error);
      clients.delete(ws);
    });
  });

  // Function to broadcast to all connected clients
  function broadcastToAll(message: any) {
    const messageStr = JSON.stringify(message);
    clients.forEach((client) => {
      if (client.readyState === WebSocket.OPEN) {
        client.send(messageStr);
      }
    });
  }

  return httpServer;
}
