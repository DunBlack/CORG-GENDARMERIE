import {
  users,
  personnel,
  vehicles,
  units,
  interventions,
  emergencyAlerts,
  vehicleAssignments,
  unitAssignments,
  interventionAssignments,
  type User,
  type UpsertUser,
  type Personnel,
  type InsertPersonnel,
  type Vehicle,
  type InsertVehicle,
  type Unit,
  type InsertUnit,
  type Intervention,
  type InsertIntervention,
  type EmergencyAlert,
  type InsertEmergencyAlert,
  type VehicleAssignment,
  type UnitAssignment,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, desc } from "drizzle-orm";

export interface IStorage {
  // User operations (mandatory for Replit Auth)
  getUser(id: string): Promise<User | undefined>;
  upsertUser(user: UpsertUser): Promise<User>;

  // Personnel operations
  getAllPersonnel(): Promise<Personnel[]>;
  getAvailablePersonnel(): Promise<Personnel[]>;
  createPersonnel(personnel: InsertPersonnel): Promise<Personnel>;
  updatePersonnelAvailability(id: number, isAvailable: boolean): Promise<void>;
  updatePersonnelAssignment(id: number, assignment: string | null): Promise<void>;

  // Vehicle operations
  getAllVehicles(): Promise<Vehicle[]>;
  getVehicleWithAssignments(id: number): Promise<Vehicle & { assignments: (VehicleAssignment & { personnel: Personnel })[] }>;
  createVehicle(vehicle: InsertVehicle): Promise<Vehicle>;
  updateVehicleStatus(id: number, status: number): Promise<void>;
  updateVehicleLocation(id: number, location: string): Promise<void>;
  updateVehicleEmergency(id: number, isEmergency: boolean): Promise<void>;

  // Unit operations
  getAllUnits(): Promise<Unit[]>;
  getUnitWithAssignments(id: number): Promise<Unit & { assignments: (UnitAssignment & { personnel: Personnel })[] }>;
  createUnit(unit: InsertUnit): Promise<Unit>;
  updateUnitStatus(id: number, status: number): Promise<void>;
  updateUnitLocation(id: number, location: string): Promise<void>;
  updateUnitEmergency(id: number, isEmergency: boolean): Promise<void>;

  // Assignment operations
  assignPersonnelToVehicle(personnelId: number, vehicleId: number, isLeader?: boolean): Promise<void>;
  assignPersonnelToUnit(personnelId: number, unitId: number): Promise<void>;
  removePersonnelFromVehicle(personnelId: number, vehicleId: number): Promise<void>;
  removePersonnelFromUnit(personnelId: number, unitId: number): Promise<void>;

  // Intervention operations
  getAllActiveInterventions(): Promise<Intervention[]>;
  createIntervention(intervention: InsertIntervention): Promise<Intervention>;
  updateInterventionLocation(id: number, location: string): Promise<void>;
  closeIntervention(id: number): Promise<void>;

  // Emergency operations
  createEmergencyAlert(alert: InsertEmergencyAlert): Promise<EmergencyAlert>;
  getActiveEmergencyAlerts(): Promise<EmergencyAlert[]>;
  resolveEmergencyAlert(id: number): Promise<void>;
}

export class DatabaseStorage implements IStorage {
  // User operations (mandatory for Replit Auth)
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async upsertUser(userData: UpsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(userData)
      .onConflictDoUpdate({
        target: users.id,
        set: {
          ...userData,
          updatedAt: new Date(),
        },
      })
      .returning();
    return user;
  }

  // Personnel operations
  async getAllPersonnel(): Promise<Personnel[]> {
    return await db.select().from(personnel);
  }

  async getAvailablePersonnel(): Promise<Personnel[]> {
    return await db.select().from(personnel).where(eq(personnel.isAvailable, true));
  }

  async createPersonnel(personnelData: InsertPersonnel): Promise<Personnel> {
    const [person] = await db.insert(personnel).values(personnelData).returning();
    return person;
  }

  async updatePersonnelAvailability(id: number, isAvailable: boolean): Promise<void> {
    await db.update(personnel).set({ isAvailable }).where(eq(personnel.id, id));
  }

  async updatePersonnelAssignment(id: number, assignment: string | null): Promise<void> {
    await db.update(personnel).set({ currentAssignment: assignment }).where(eq(personnel.id, id));
  }

  // Vehicle operations
  async getAllVehicles(): Promise<Vehicle[]> {
    return await db.select().from(vehicles);
  }

  async getVehicleWithAssignments(id: number) {
    const vehicle = await db.select().from(vehicles).where(eq(vehicles.id, id));
    const assignments = await db
      .select({
        id: vehicleAssignments.id,
        vehicleId: vehicleAssignments.vehicleId,
        personnelId: vehicleAssignments.personnelId,
        isLeader: vehicleAssignments.isLeader,
        assignedAt: vehicleAssignments.assignedAt,
        personnel: personnel,
      })
      .from(vehicleAssignments)
      .innerJoin(personnel, eq(vehicleAssignments.personnelId, personnel.id))
      .where(eq(vehicleAssignments.vehicleId, id));

    return { ...vehicle[0], assignments };
  }

  async createVehicle(vehicleData: InsertVehicle): Promise<Vehicle> {
    const [vehicle] = await db.insert(vehicles).values(vehicleData).returning();
    return vehicle;
  }

  async updateVehicleStatus(id: number, status: number): Promise<void> {
    await db.update(vehicles).set({ status, updatedAt: new Date() }).where(eq(vehicles.id, id));
  }

  async updateVehicleLocation(id: number, location: string): Promise<void> {
    await db.update(vehicles).set({ currentLocation: location, updatedAt: new Date() }).where(eq(vehicles.id, id));
  }

  async updateVehicleEmergency(id: number, isEmergency: boolean): Promise<void> {
    await db.update(vehicles).set({ isEmergency, updatedAt: new Date() }).where(eq(vehicles.id, id));
  }

  // Unit operations
  async getAllUnits(): Promise<Unit[]> {
    return await db.select().from(units);
  }

  async getUnitWithAssignments(id: number) {
    const unit = await db.select().from(units).where(eq(units.id, id));
    const assignments = await db
      .select({
        id: unitAssignments.id,
        unitId: unitAssignments.unitId,
        personnelId: unitAssignments.personnelId,
        assignedAt: unitAssignments.assignedAt,
        personnel: personnel,
      })
      .from(unitAssignments)
      .innerJoin(personnel, eq(unitAssignments.personnelId, personnel.id))
      .where(eq(unitAssignments.unitId, id));

    return { ...unit[0], assignments };
  }

  async createUnit(unitData: InsertUnit): Promise<Unit> {
    const [unit] = await db.insert(units).values(unitData).returning();
    return unit;
  }

  async updateUnitStatus(id: number, status: number): Promise<void> {
    await db.update(units).set({ status, updatedAt: new Date() }).where(eq(units.id, id));
  }

  async updateUnitLocation(id: number, location: string): Promise<void> {
    await db.update(units).set({ currentLocation: location, updatedAt: new Date() }).where(eq(units.id, id));
  }

  async updateUnitEmergency(id: number, isEmergency: boolean): Promise<void> {
    await db.update(units).set({ isEmergency, updatedAt: new Date() }).where(eq(units.id, id));
  }

  // Assignment operations
  async assignPersonnelToVehicle(personnelId: number, vehicleId: number, isLeader = false): Promise<void> {
    await db.insert(vehicleAssignments).values({
      personnelId,
      vehicleId,
      isLeader,
    });
    await this.updatePersonnelAvailability(personnelId, false);
    await this.updatePersonnelAssignment(personnelId, `vehicle-${vehicleId}`);
  }

  async assignPersonnelToUnit(personnelId: number, unitId: number): Promise<void> {
    await db.insert(unitAssignments).values({
      personnelId,
      unitId,
    });
    await this.updatePersonnelAvailability(personnelId, false);
    await this.updatePersonnelAssignment(personnelId, `unit-${unitId}`);
  }

  async removePersonnelFromVehicle(personnelId: number, vehicleId: number): Promise<void> {
    await db.delete(vehicleAssignments).where(
      and(
        eq(vehicleAssignments.personnelId, personnelId),
        eq(vehicleAssignments.vehicleId, vehicleId)
      )
    );
    await this.updatePersonnelAvailability(personnelId, true);
    await this.updatePersonnelAssignment(personnelId, null);
  }

  async removePersonnelFromUnit(personnelId: number, unitId: number): Promise<void> {
    await db.delete(unitAssignments).where(
      and(
        eq(unitAssignments.personnelId, personnelId),
        eq(unitAssignments.unitId, unitId)
      )
    );
    await this.updatePersonnelAvailability(personnelId, true);
    await this.updatePersonnelAssignment(personnelId, null);
  }

  // Intervention operations
  async getAllActiveInterventions(): Promise<Intervention[]> {
    return await db.select().from(interventions).where(eq(interventions.status, "active")).orderBy(desc(interventions.createdAt));
  }

  async createIntervention(interventionData: InsertIntervention): Promise<Intervention> {
    const [intervention] = await db.insert(interventions).values(interventionData).returning();
    return intervention;
  }

  async updateInterventionLocation(id: number, location: string): Promise<void> {
    await db.update(interventions).set({ location, updatedAt: new Date() }).where(eq(interventions.id, id));
  }

  async closeIntervention(id: number): Promise<void> {
    await db.update(interventions).set({ status: "closed", updatedAt: new Date() }).where(eq(interventions.id, id));
  }

  // Emergency operations
  async createEmergencyAlert(alertData: InsertEmergencyAlert): Promise<EmergencyAlert> {
    const [alert] = await db.insert(emergencyAlerts).values(alertData).returning();
    return alert;
  }

  async getActiveEmergencyAlerts(): Promise<EmergencyAlert[]> {
    return await db.select().from(emergencyAlerts).where(eq(emergencyAlerts.isResolved, false)).orderBy(desc(emergencyAlerts.createdAt));
  }

  async resolveEmergencyAlert(id: number): Promise<void> {
    await db.update(emergencyAlerts).set({ isResolved: true, resolvedAt: new Date() }).where(eq(emergencyAlerts.id, id));
  }
}

export const storage = new DatabaseStorage();
