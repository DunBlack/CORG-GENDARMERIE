import {
  pgTable,
  text,
  varchar,
  timestamp,
  jsonb,
  index,
  serial,
  integer,
  boolean,
} from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { relations } from "drizzle-orm";

// Session storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const sessions = pgTable(
  "sessions",
  {
    sid: varchar("sid").primaryKey(),
    sess: jsonb("sess").notNull(),
    expire: timestamp("expire").notNull(),
  },
  (table) => [index("IDX_session_expire").on(table.expire)],
);

// User storage table.
// (IMPORTANT) This table is mandatory for Replit Auth, don't drop it.
export const users = pgTable("users", {
  id: varchar("id").primaryKey().notNull(),
  email: varchar("email").unique(),
  firstName: varchar("first_name"),
  lastName: varchar("last_name"),
  profileImageUrl: varchar("profile_image_url"),
  role: varchar("role").notNull().default("gendarme"), // gendarme, corg, admin
  rank: varchar("rank"), // Gdt, Brig, Adj, Mdl, etc.
  badge: varchar("badge"), // matricule
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Personnel table for dispatch management
export const personnel = pgTable("personnel", {
  id: serial("id").primaryKey(),
  userId: varchar("user_id").references(() => users.id),
  name: varchar("name").notNull(),
  rank: varchar("rank").notNull(),
  badge: varchar("badge").notNull(),
  isAvailable: boolean("is_available").default(true),
  currentAssignment: varchar("current_assignment"), // vehicle/unit ID they're assigned to
  createdAt: timestamp("created_at").defaultNow(),
});

// Vehicles table
export const vehicles = pgTable("vehicles", {
  id: serial("id").primaryKey(),
  callSign: varchar("call_sign").notNull(), // Alpha-1, Alpha-2, etc.
  model: varchar("model").notNull(),
  registration: varchar("registration").notNull(),
  type: varchar("type").notNull().default("patrol"), // patrol, specialized
  status: integer("status").default(0), // 0=available, 1-5=status codes
  currentLocation: text("current_location"),
  isEmergency: boolean("is_emergency").default(false),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Specialized units table
export const units = pgTable("units", {
  id: serial("id").primaryKey(),
  name: varchar("name").notNull(),
  type: varchar("type").notNull(), // motard, cyno, etc.
  description: text("description"),
  status: integer("status").default(0),
  currentLocation: text("current_location"),
  isEmergency: boolean("is_emergency").default(false),
  maxPersonnel: integer("max_personnel").default(1),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Vehicle assignments
export const vehicleAssignments = pgTable("vehicle_assignments", {
  id: serial("id").primaryKey(),
  vehicleId: integer("vehicle_id").references(() => vehicles.id),
  personnelId: integer("personnel_id").references(() => personnel.id),
  isLeader: boolean("is_leader").default(false),
  assignedAt: timestamp("assigned_at").defaultNow(),
});

// Unit assignments
export const unitAssignments = pgTable("unit_assignments", {
  id: serial("id").primaryKey(),
  unitId: integer("unit_id").references(() => units.id),
  personnelId: integer("personnel_id").references(() => personnel.id),
  assignedAt: timestamp("assigned_at").defaultNow(),
});

// Interventions table
export const interventions = pgTable("interventions", {
  id: serial("id").primaryKey(),
  title: varchar("title").notNull(),
  description: text("description"),
  location: text("location").notNull(),
  status: varchar("status").default("active"), // active, closed
  priority: varchar("priority").default("normal"), // low, normal, high, emergency
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

// Intervention assignments
export const interventionAssignments = pgTable("intervention_assignments", {
  id: serial("id").primaryKey(),
  interventionId: integer("intervention_id").references(() => interventions.id),
  vehicleId: integer("vehicle_id").references(() => vehicles.id),
  unitId: integer("unit_id").references(() => units.id),
  assignedAt: timestamp("assigned_at").defaultNow(),
});

// Emergency alerts table
export const emergencyAlerts = pgTable("emergency_alerts", {
  id: serial("id").primaryKey(),
  vehicleId: integer("vehicle_id"),
  unitId: integer("unit_id"),
  message: text("message").notNull(),
  isResolved: boolean("is_resolved").default(false),
  createdBy: varchar("created_by").references(() => users.id),
  createdAt: timestamp("created_at").defaultNow(),
  resolvedAt: timestamp("resolved_at"),
});

// Relations
export const usersRelations = relations(users, ({ many }) => ({
  personnel: many(personnel),
  interventions: many(interventions),
  emergencyAlerts: many(emergencyAlerts),
}));

export const personnelRelations = relations(personnel, ({ one, many }) => ({
  user: one(users, { fields: [personnel.userId], references: [users.id] }),
  vehicleAssignments: many(vehicleAssignments),
  unitAssignments: many(unitAssignments),
}));

export const vehiclesRelations = relations(vehicles, ({ many }) => ({
  assignments: many(vehicleAssignments),
  interventionAssignments: many(interventionAssignments),
  emergencyAlerts: many(emergencyAlerts),
}));

export const unitsRelations = relations(units, ({ many }) => ({
  assignments: many(unitAssignments),
  interventionAssignments: many(interventionAssignments),
  emergencyAlerts: many(emergencyAlerts),
}));

export const interventionsRelations = relations(interventions, ({ one, many }) => ({
  createdByUser: one(users, { fields: [interventions.createdBy], references: [users.id] }),
  assignments: many(interventionAssignments),
}));

// Insert schemas
export const insertUserSchema = createInsertSchema(users).omit({
  createdAt: true,
  updatedAt: true,
});

export const insertPersonnelSchema = createInsertSchema(personnel).omit({
  id: true,
  createdAt: true,
});

export const insertVehicleSchema = createInsertSchema(vehicles).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertUnitSchema = createInsertSchema(units).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertInterventionSchema = createInsertSchema(interventions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertEmergencyAlertSchema = createInsertSchema(emergencyAlerts).omit({
  id: true,
  createdAt: true,
  resolvedAt: true,
  vehicleId: true,
  unitId: true,
}).extend({
  vehicleId: z.number().optional(),
  unitId: z.number().optional(),
});

// Types
export type UpsertUser = typeof users.$inferInsert;
export type User = typeof users.$inferSelect;
export type Personnel = typeof personnel.$inferSelect;
export type InsertPersonnel = z.infer<typeof insertPersonnelSchema>;
export type Vehicle = typeof vehicles.$inferSelect;
export type InsertVehicle = z.infer<typeof insertVehicleSchema>;
export type Unit = typeof units.$inferSelect;
export type InsertUnit = z.infer<typeof insertUnitSchema>;
export type Intervention = typeof interventions.$inferSelect;
export type InsertIntervention = z.infer<typeof insertInterventionSchema>;
export type EmergencyAlert = typeof emergencyAlerts.$inferSelect;
export type InsertEmergencyAlert = z.infer<typeof insertEmergencyAlertSchema>;
export type VehicleAssignment = typeof vehicleAssignments.$inferSelect;
export type UnitAssignment = typeof unitAssignments.$inferSelect;
export type InterventionAssignment = typeof interventionAssignments.$inferSelect;
